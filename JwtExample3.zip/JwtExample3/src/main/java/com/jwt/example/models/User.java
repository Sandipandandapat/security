package com.jwt.example.models;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class User {
    private String userId;
    private String name;
    private String email;
}
